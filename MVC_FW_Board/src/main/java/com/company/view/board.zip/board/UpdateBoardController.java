package com.company.view.board;

import com.company.view.controller.Controller;

public class UpdateBoardController implements Controller {

}
