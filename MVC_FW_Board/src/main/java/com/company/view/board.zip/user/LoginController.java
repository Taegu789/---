package com.company.view.user;

import javax.servlet.http.HttpServletRequest;

import com.company.view.controller.Controller;

public class LoginController implements Controller{

	@Override
	public String handlerRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}

}
